package com.example.reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

public class FileRead {
	
	public static void main(String[] args) {

		try {
		FileReader fr=new FileReader("C:\\\\file.txt");    
        BufferedReader br=new BufferedReader(fr);   
        
        int i; 
        
        while((i=br.read())!=-1){  
        System.out.print((char)i);  
        }  
        br.close();    
        fr.close();    
		
	}catch(Exception e) {
		e.printStackTrace(); 
	}
		
	}


}

package com.example.reader;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class FileWrite {

	public static void main(String[] args) {

		try {

			FileWriter writer = new FileWriter("C:\\file.txt");  
			BufferedWriter buffer = new BufferedWriter(writer);  
			buffer.write("write the word file,My name is sonam gour");  
			buffer.close();  
			System.out.println("Success"); 

		}catch(Exception e) {
			e.printStackTrace(); 
		}
	}
}



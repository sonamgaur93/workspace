package com.storage.springbootbucket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootbucketApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootbucketApplication.class, args);
	}

}

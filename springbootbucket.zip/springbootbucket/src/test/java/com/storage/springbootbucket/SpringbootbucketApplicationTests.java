package com.storage.springbootbucket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootbucketApplicationTests {

	@Test
	void contextLoads() {
	}

}

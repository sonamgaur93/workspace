package com.example.comparatortest;

import java.io.*;
import java.util.*;
import java.util.stream.*;


public class SolutionSecond {
	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));


		int t = Integer.parseInt(bufferedReader.readLine().trim());

		IntStream.range(0, t).forEach(tItr -> {
			try {

				String s = bufferedReader.readLine();

				String result = Resul.isBalanced(s);

				bufferedWriter.write(result);
				bufferedWriter.newLine();

				System.err.println(result);
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
		});

		bufferedReader.close();
		bufferedWriter.close();
	}
}



class Resul {
	public static String isBalanced(String s) { 

		Stack<Character> stack = new Stack<Character>();

		for(int i=0;i<s.length();i++){

			char ch = s.charAt(i);

			if(ch =='(' || ch =='{'|| ch =='['){
				stack.push(s.charAt(i));

			}else
			{
				if(stack.isEmpty()){
					return "NO";
				}
				else{
					char check;
					switch (ch) {
					case ')':
						check = stack.pop();
						if (check == '{' || check == '[')
							return "No";
						break;

					case '}':
						check = stack.pop();
						if (check == '(' || check == '[')
							return "No";
						break;

					case ']':
						check = stack.pop();
						if (check == '(' || check == '{')
							return "No";
						break;
					}
				}
			}
		}
		if(stack.isEmpty()){
			return "YES";
		}

		else{
			return "NO";
		}
	}
}


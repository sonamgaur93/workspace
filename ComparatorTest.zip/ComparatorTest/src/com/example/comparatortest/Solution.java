package com.example.comparatortest;

import static java.util.stream.Collectors.toList;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;



public class Solution {
	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));


		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(
				System.getenv("OUTPUT_PATH")));


		int n = Integer.parseInt(bufferedReader.readLine().trim());

		int k = Integer.parseInt(bufferedReader.readLine().trim());

		List<Integer> arr = IntStream.range(0, n).mapToObj(i -> {
			try {
				return bufferedReader.readLine().replaceAll("\\s+$", "");
			} catch (IOException ex) {
				throw new RuntimeException(ex);
			}
		})
				.map(String::trim)
				.map(Integer::parseInt)
				.collect(toList());

		int result = Result.maxMin(k, arr);

		bufferedWriter.write(String.valueOf(result));
		bufferedWriter.newLine();

		bufferedReader.close();
		bufferedWriter.close();
	}
}

class Result {

	public static int maxMin(int k, List<Integer> arr) {
		
		int max = getMax(arr.subList(0, k));
		int min = getMin(arr.subList(0, k));
		
		System.err.println(max-min);
		return 1;

	}

	public static int getMax(List<Integer> subList) {
		
		Integer[] aarry = subList.stream().toArray(Integer[] :: new);
		Integer max = aarry[0];

		for(int i=0;i<aarry.length;i++) {

			if(max<aarry[i]) {
				max=aarry[i];
			}
		}
		return max;
	}


	private static int getMin(List<Integer> subList) {
		Integer[] aarry = subList.stream().toArray(Integer[] :: new);
		Integer min = aarry[0];

		for(int i=0;i<aarry.length;i++) {

			if(min>aarry[i]) {
				min=aarry[i];
			}
		}
		return min;
	}

}

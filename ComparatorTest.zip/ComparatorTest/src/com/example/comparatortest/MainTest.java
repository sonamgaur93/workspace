package com.example.comparatortest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Player{

	String name;
	Integer score;
	public Player(String name, Integer score) {

		this.name = name;
		this.score = score;
	}
	
	@Override
	public String toString() {
		return "name=" + name + " score=" + score + "\n";
	}

}


class Checker implements Comparator<Player>{


	@Override
	public int compare(Player o1, Player o2) {

		if(o1.score.equals(o2.score)) {
			return o1!=null && o2!=null ? o1.name.compareTo(o2.name) :0;

		}else if(o1.score>o2.score) {
			return -1;

		}else if(o1.score<o2.score) {
			return 1;

		}else {
			return 0;
		}
	}
}


public class MainTest {

	public static void main(String[] args) {

		Player p1 = new Player("erica" , 100);
		Player p2 = new Player("david" , 100);
		Player p3 = new Player("heraldo" , 50);
		Player p4 = new Player("aakansha" , 75);
		Player p5 = new Player("aleksa " , 150);

		List<Player> listPlayer = new ArrayList<>();
		listPlayer.add(p1);
		listPlayer.add(p2);
		listPlayer.add(p3);
		listPlayer.add(p4);
		listPlayer.add(p5);

		Checker checker=  new Checker();

		Collections.sort(listPlayer,checker);

		System.err.println(listPlayer);
	}
}

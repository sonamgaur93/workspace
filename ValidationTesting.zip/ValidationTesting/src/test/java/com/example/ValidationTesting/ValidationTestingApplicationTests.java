package com.example.ValidationTesting;

import static org.junit.jupiter.api.Assertions.assertEquals;



import static org.mockito.Mockito.when;



import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.ValidationTesting.Dto.RequestDto;

import com.example.ValidationTesting.Entity.User;
import com.example.ValidationTesting.Repo.UserRepository;
import com.example.ValidationTesting.serviceImpl.ServiceImpl;


@SpringBootTest
class ValidationTestingApplicationTests {

	@Mock
	UserRepository userRepoMock;

	@InjectMocks
	ServiceImpl serviceMock;

	@Test
	public void saveUserTest() {
		RequestDto request = new RequestDto();

		request.setId(1);
		request.setUsername("sonam");
		request.setAddress("malhargarh");
		request.setPassword("1234");
		request.setEmail("sonam@gmm.co");

		User user = new User();
		user.setId(request.getId());
		user.setUsername(request.getUsername());
		user.setAddress(request.getAddress());
		user.setPassword(request.getPassword());
		user.setEmail(request.getEmail());

		when(userRepoMock.save(user)).thenReturn(user);


		assertEquals(user,serviceMock.saveUser(request));
	}
}

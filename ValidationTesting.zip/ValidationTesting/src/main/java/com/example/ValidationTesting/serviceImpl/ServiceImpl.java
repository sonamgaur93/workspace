package com.example.ValidationTesting.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ValidationTesting.Dto.RequestDto;
import com.example.ValidationTesting.Dto.ResponseDto;
import com.example.ValidationTesting.Entity.User;
import com.example.ValidationTesting.Repo.UserRepository;
import com.example.ValidationTesting.service.UserService;

@Service
public class ServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepository;

	@Override
	public ResponseDto saveUser(RequestDto userRequest) {
		
		ResponseDto responseDto= new ResponseDto();
		
		User user =new User();
		
		user.setId(userRequest.getId());
		user.setUsername(userRequest.getUsername());
		user.setAddress(userRequest.getAddress());
		user.setEmail(userRequest.getEmail());
		user.setPassword(userRequest.getPassword());
		
		userRepository.save(user);
		
		responseDto.setId(user.getId());
		responseDto.setUsername(user.getUsername());
		responseDto.setAddress(user.getAddress());
		responseDto.setEmail(user.getEmail());
		responseDto.setPassword(user.getPassword());
		System.err.println(responseDto);
		return responseDto;
	}

}

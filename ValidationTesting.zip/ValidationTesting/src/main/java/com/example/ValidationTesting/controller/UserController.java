package com.example.ValidationTesting.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ValidationTesting.Dto.RequestDto;
import com.example.ValidationTesting.Dto.ResponseDto;
import com.example.ValidationTesting.service.UserService;


@RestController
public class UserController {
	
	@Autowired
	UserService service;
	
	@Value("${server.port}")
	private String serverPort;
	
	@GetMapping("/profiles")
	public void profileTesting() {
		System.out.println("my server port:" +serverPort);
	}
	
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public @ResponseBody ResponseDto saveUser(@RequestBody @Validated RequestDto userRequest) {
		return service.saveUser(userRequest);

	}


}

package com.example.ValidationTesting.service;

import com.example.ValidationTesting.Dto.RequestDto;
import com.example.ValidationTesting.Dto.ResponseDto;

public interface UserService {

	ResponseDto saveUser(RequestDto userRequest); 	

}

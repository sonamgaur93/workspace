package com.example.ValidationTesting.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "user")
public class User {
	
	
	@Id
	@GeneratedValue( strategy=GenerationType.AUTO )
	private Integer id;

	@Column
	private String username;

	@Column
	private String email;

	@Column
	private String address;

	@Column
	private String password;


}

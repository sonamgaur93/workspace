package com.example.ValidationTesting.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ValidationTesting.Entity.User;


public interface UserRepository extends JpaRepository<User, Integer>{

}

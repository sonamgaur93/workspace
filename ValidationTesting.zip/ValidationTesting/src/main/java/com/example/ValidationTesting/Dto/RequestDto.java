package com.example.ValidationTesting.Dto;

import javax.validation.constraints.NotEmpty;

public class RequestDto {

	private Integer id;

	@NotEmpty(message="name must be filled")
	private String username;

	@NotEmpty(message="email should be filled")
	private String email;

	@NotEmpty(message="address should be filled")
	private String address;
	private String password;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "RequestDto [id=" + id + ", username=" + username + ", email=" + email + ", address=" + address
				+ ", password=" + password + "]";
	}


}

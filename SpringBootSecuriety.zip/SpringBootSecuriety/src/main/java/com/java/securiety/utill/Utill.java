package com.java.securiety.utill;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

public class Utill {

	public UserDetails getUserDetails() {
		UserDetails user =
				User.builder()
				.username("user")
				.password("password")
				.roles("USER")
				.build();
		return user;
	}

}

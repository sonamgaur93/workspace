package com.javatechie.report.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.javatechie.report.repository.EmployeeRepository;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;



@Service
public class ReportService {

	@Autowired
	private EmployeeRepository repository;


	public String exportReport(String reportFormat) throws FileNotFoundException, JRException {

		String path = "C:\\Users\\DELL\\Desktop\\Jasper-workspace";
		Map<String, Object> parameters = new HashMap<>();
		
		
		File file = ResourceUtils.getFile("C:\\Users\\DELL\\Desktop\\work-sapce\\spring-jasper-report\\src\\main\\resources\\cv.jrxml");
		
		JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(List.of(new Data("name","@gamil", "address1")));
		JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, dataSource);
		JasperExportManager.exportReportToPdfFile(jasperPrint, "C:\\Users\\DELL\\Desktop\\work-sapce\\spring-jasper-report\\cv.pdf");
	

		return "report generated sccessfully ";


		//        String path = "C:\\Users\\DELL\\Desktop\\Jasper-workspace";
		//      List<Employee> employees = repository.findAll();
		//        
		//       
		//        //load file and compile it
		//        File file = ResourceUtils.getFile("classpath:employees.jrxml");
		//        JasperReport jasperReport = JasperCompileManager.compileReport(file.getAbsolutePath());
		//        JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(employees);
		//        
		//        Map<String, Object> parameters = new HashMap<>();
		//        parameters.put("createdBy", "Java Techie");
		//        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dataSource);
		//        if (reportFormat.equalsIgnoreCase("html")) {
		//            JasperExportManager.exportReportToHtmlFile(jasperPrint, path + "\\employees.html");
		//        }
//		       if (reportFormat.equalsIgnoreCase("pdf")) {
		//            JasperExportManager.exportReportToPdfFile(jasperPrint, path + "\\employees.pdf");
		//        }
		//
		//        return "report generated in path : " + path;
	}
}

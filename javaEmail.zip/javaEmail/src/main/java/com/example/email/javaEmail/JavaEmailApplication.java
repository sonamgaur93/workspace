package com.example.email.javaEmail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;

@SpringBootApplication
public class JavaEmailApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaEmailApplication.class, args);
	}




	@Bean
	public SimpleMailMessage simpleMailMessage() {
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setSubject("MailCheck");
		mailMessage.setText("");
		return mailMessage;
	}
}

package com.example.email.javaEmail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class JavaEmailController {
	
	@Autowired
	JavaEmailService javaEmailService;

	@RequestMapping(value = "/sendmail", method = RequestMethod.POST)
	public String sendSimpleEmail(@RequestParam("toEmail")String toEmail, @RequestParam("subject") String subject, @RequestBody String body) {
		javaEmailService.sendSimpleEmail(toEmail, subject, body);
		return "ok";
	}
	
	@RequestMapping(value = "/sendAttachment", method = RequestMethod.POST)
	public String sendAttachment(@RequestParam("toEmail")String toEmail, @RequestParam("dear")String dear, @RequestBody String body) {
		javaEmailService.sendMail(toEmail, dear, body);
		return "ok";
	}


}

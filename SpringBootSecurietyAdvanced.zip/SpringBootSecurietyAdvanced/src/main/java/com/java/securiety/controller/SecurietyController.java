package com.java.securiety.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecurietyController {

	@GetMapping("/users")
	public String usersStatus() {
		return "Authorized user";
	}

	@GetMapping("/managers")
	public String managersStatusCheck() {
		return "Authorized manager";
	}

}
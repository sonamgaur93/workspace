package com.java.securiety;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurietyAdvancedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurietyAdvancedApplication.class, args);
	}

}

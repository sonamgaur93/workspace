package com.java.securiety;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurietyAdvancedApplicationTests {

	@Test
	void contextLoads() {
	}

}

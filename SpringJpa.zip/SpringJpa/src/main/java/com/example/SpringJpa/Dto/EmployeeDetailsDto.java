package com.example.SpringJpa.Dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.example.SpringJpa.Entity.Address;
import com.example.SpringJpa.Entity.Department;


import lombok.Data;
@Data
public class EmployeeDetailsDto {
	private Integer id;

	private String name;

	
	private String gender;

	
	private String designation;

	
	private long salary;

	
	private DepartmentDto department;

	
	private List<AddressDto> address;


}

package com.example.SpringJpa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringJpa.Entity.Address;



public interface AddressRepository extends JpaRepository<Address, Integer>{

}

package com.example.SpringJpa.Dto;

import java.util.List;

import lombok.Data;
@Data
public class EmployeeRequestDto {
	private Integer id;

	private String name;

	
	private String gender;

	
	private String designation;

	
	private long salary;

	
	private DepartmentDto department;

	
	private List<AddressDto> address;



}

package com.example.SpringJpa.Dto;



import lombok.Data;
@Data
public class AddressDto {
	
   private Integer id;
	
	
	private String city;
	
	
	private String state;

	
	private String country;

}

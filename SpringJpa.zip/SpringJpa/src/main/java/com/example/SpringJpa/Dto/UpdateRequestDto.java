package com.example.SpringJpa.Dto;

public class UpdateRequestDto {
	private Integer id;
	private String designation;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "UpdateRequestDto [id=" + id + ", designation=" + designation + "]";
	}

}

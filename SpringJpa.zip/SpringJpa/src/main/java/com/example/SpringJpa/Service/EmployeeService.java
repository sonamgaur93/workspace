package com.example.SpringJpa.Service;

import com.example.SpringJpa.Dto.EmployeeDetailsDto;
import com.example.SpringJpa.Dto.EmployeeRequestDto;
import com.example.SpringJpa.Dto.UpdateRequestDto;

public interface EmployeeService {

	EmployeeDetailsDto saveEmployee(EmployeeRequestDto employeeRequest);

	String deleteEmployee(int id);

	EmployeeDetailsDto getEmployee(int id);

	EmployeeDetailsDto updateEmployee(UpdateRequestDto updateRequest);

}

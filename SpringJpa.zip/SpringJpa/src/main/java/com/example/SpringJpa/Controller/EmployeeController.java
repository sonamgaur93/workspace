package com.example.SpringJpa.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringJpa.Dto.EmployeeDetailsDto;
import com.example.SpringJpa.Dto.EmployeeRequestDto;
import com.example.SpringJpa.Dto.UpdateRequestDto;
import com.example.SpringJpa.Service.EmployeeService;

@RestController
public class EmployeeController {


	@Autowired
	EmployeeService employeeService;

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public String deleteEmployee( @PathVariable("id") int id) {
		return employeeService.deleteEmployee(id);
	}



	@RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	public @ResponseBody EmployeeDetailsDto saveEmployee(@RequestBody EmployeeRequestDto employeeRequest) {
		return employeeService.saveEmployee(employeeRequest);

	}



	@RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
	public @ResponseBody EmployeeDetailsDto getEmployee(@PathVariable("id") int id) {
		return employeeService.getEmployee(id);

	}


	@RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	public @ResponseBody EmployeeDetailsDto updateEmployee(@PathVariable("id") int id , @RequestBody UpdateRequestDto  updateRequest) {
		return employeeService.updateEmployee(updateRequest);

	}

}

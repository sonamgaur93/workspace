package com.example.SpringJpa.Dto;



import lombok.Data;

@Data
public class DepartmentDto {
	
	   private Integer id;
	   
	  
	   private String name;

}

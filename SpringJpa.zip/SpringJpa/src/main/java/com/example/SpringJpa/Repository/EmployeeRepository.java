package com.example.SpringJpa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringJpa.Entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}

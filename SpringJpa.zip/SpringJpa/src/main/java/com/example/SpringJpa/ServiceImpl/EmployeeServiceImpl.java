package com.example.SpringJpa.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringJpa.Dto.AddressDto;
import com.example.SpringJpa.Dto.DepartmentDto;
import com.example.SpringJpa.Dto.EmployeeDetailsDto;
import com.example.SpringJpa.Dto.EmployeeRequestDto;
import com.example.SpringJpa.Dto.UpdateRequestDto;
import com.example.SpringJpa.Entity.Address;
import com.example.SpringJpa.Entity.Department;
import com.example.SpringJpa.Entity.Employee;
import com.example.SpringJpa.Repository.AddressRepository;
import com.example.SpringJpa.Repository.DepartmentRepository;
import com.example.SpringJpa.Repository.EmployeeRepository;
import com.example.SpringJpa.Service.EmployeeService;


@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	EmployeeRepository employeeRepository;
	@Autowired
	DepartmentRepository  departmentRepository; 

	@Autowired
	AddressRepository  addressRepository;

	@Override
	public EmployeeDetailsDto saveEmployee(EmployeeRequestDto employeeRequest) {

		EmployeeDetailsDto employeeDetailsDto = new EmployeeDetailsDto();  
		
		DepartmentDto departmentDto = new DepartmentDto();

		Employee employee = new Employee(); 
		Department department = new Department(); 


		employee.setName(employeeRequest.getName());
		employee.setGender(employeeRequest.getGender());
		employee.setDesignation(employeeRequest.getDesignation());
		employee.setSalary(employeeRequest.getSalary());

		department.setName(employeeRequest.getDepartment().getName());

		employee.setDepartment(department);

		List<Address> addresses = new ArrayList<Address>(); 

		for(AddressDto address:employeeRequest.getAddress()) {
			Address adrss= new Address();
			adrss.setCity(address.getCity());
			adrss.setState(address.getState());
			adrss.setCountry(address.getCountry());

			addresses.add(adrss);
		}

		
		
		employee.setAddress(addresses);

		
		
		
		Employee employeeData = employeeRepository.save(employee);
		
//		Handle by @Transactional 
		System.err.println(10/0);

		employeeDetailsDto.setId(employeeData.getId());
		employeeDetailsDto.setName(employeeData.getName());
		employeeDetailsDto.setGender(employeeData.getGender());
		employeeDetailsDto.setDesignation(employeeData.getDesignation());
		employeeDetailsDto.setSalary(employeeData.getSalary());


		departmentDto.setId(employeeData.getDepartment().getId());
		departmentDto.setName(employeeData.getDepartment().getName());


		List<AddressDto> addressDtoList =new ArrayList<AddressDto>();

		for(Address address:employeeData.getAddress()) {
			AddressDto adrss= new AddressDto();
			adrss.setId(address.getId());
			adrss.setCity(address.getCity());
			adrss.setState(address.getState());
			adrss.setCountry(address.getCountry());

			addressDtoList.add(adrss);
		}


		employeeDetailsDto.setDepartment(departmentDto);
		employeeDetailsDto.setAddress(addressDtoList);

		return employeeDetailsDto;


	}

	@Override
	public String deleteEmployee(int id) {
		String s=new String("success");
		
		employeeRepository.deleteById(id);
		return s ;
	}

	@Override
	public EmployeeDetailsDto getEmployee(int id) {
		EmployeeDetailsDto employeeDetailsDto= new EmployeeDetailsDto();

		Optional<Employee> employeeOptional=employeeRepository.findById(id);
		if(employeeOptional.isPresent()) { 
			Employee employee= employeeOptional.get();

			employeeDetailsDto.setId(employee.getId());
			employeeDetailsDto.setName(employee.getName());
			employeeDetailsDto.setGender(employee.getGender());
			employeeDetailsDto.setDesignation(employee.getDesignation());
			employeeDetailsDto.setSalary(employee.getSalary());


			DepartmentDto departmentDto=new DepartmentDto();
			departmentDto.setId(employee.getDepartment().getId());
			departmentDto.setName(employee.getDepartment().getName());
			employeeDetailsDto.setDepartment(departmentDto);

			List<AddressDto> addressDtoList=new ArrayList<AddressDto>();

			for(Address adt:employee.getAddress()) {
				AddressDto addressDto = new AddressDto();
				addressDto.setId(adt.getId());
				addressDto.setCity(adt.getCity());
				addressDto.setCountry(adt.getCountry());
				addressDto.setState(adt.getState());
				addressDtoList.add(addressDto);
			}
			employeeDetailsDto.setAddress(addressDtoList);

		}
		return employeeDetailsDto;
	}

	@Override
	public EmployeeDetailsDto updateEmployee(UpdateRequestDto updateRequest) {

		EmployeeDetailsDto employeeDetailsDto=new EmployeeDetailsDto();
		DepartmentDto departmentDto=new DepartmentDto();


		Optional<Employee> employeeOptional=employeeRepository.findById(updateRequest.getId());
		 if(employeeOptional.isPresent()) {
			Employee employee=employeeOptional.get();
			employee.setDesignation(updateRequest.getDesignation());
			

			employeeDetailsDto.setId(employee.getId());
			employeeDetailsDto.setName(employee.getName());
			employeeDetailsDto.setSalary(employee.getSalary());
			employeeDetailsDto.setGender(employee.getGender());
			employeeDetailsDto.setDesignation(employee.getDesignation());


			departmentDto.setId(employee.getDepartment().getId());
			departmentDto.setName(employee.getDepartment().getName());
			employeeDetailsDto.setDepartment(departmentDto);

			List<AddressDto> addressDto=new ArrayList<AddressDto>();

			for(Address address:employee.getAddress()) {
				AddressDto addressDtoNew=new AddressDto();
				addressDtoNew.setCity(address.getCity());
				addressDtoNew.setCountry(address.getCountry());
				addressDtoNew.setState(address.getState());
				addressDto.add(addressDtoNew);
			}
			
			employeeDetailsDto.setAddress(addressDto);
			employeeRepository.save(employee);
         }
		return employeeDetailsDto;
	}
}

package com.example.SpringJpa.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringJpa.Entity.Department;


public interface DepartmentRepository extends JpaRepository<Department, Integer>{

}

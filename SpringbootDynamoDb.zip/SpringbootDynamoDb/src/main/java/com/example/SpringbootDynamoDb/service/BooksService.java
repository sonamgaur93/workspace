package com.example.SpringbootDynamoDb.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringbootDynamoDb.dto.BooksDto;
import com.example.SpringbootDynamoDb.dto.RequestBooksDto;
import com.example.SpringbootDynamoDb.entity.Books;
import com.example.SpringbootDynamoDb.repo.BooksRepo;

@Service
public class BooksService {

	@Autowired
	private BooksRepo booksRepo;

	public BooksDto saveBooks(BooksDto booksDto) {
		Books books = new Books();

		books.setBook_id(booksDto.getBook_id());
		books.setBook_name(booksDto.getBook_name());
		books.setBook_authorizar(booksDto.getBook_authorizar());
		books.setBook_price(booksDto.getBook_price());
		books.setCustomer_id(booksDto.getCustomer_id());

		BooksDto booksDto2 = new BooksDto();

		booksRepo.saveBooks(books);

		booksDto2.setBook_id(books.getBook_id());
		booksDto2.setBook_name(books.getBook_name());
		booksDto2.setBook_authorizar(books.getBook_authorizar());
		booksDto2.setBook_price(books.getBook_price());
		booksDto2.setCustomer_id(books.getCustomer_id());

		return booksDto2;

	}

	public BooksDto getBooksById(String book_id , String book_authorizer) {

		Books books=booksRepo.getBooksById(book_id ,book_authorizer);

		BooksDto  booksDto= new BooksDto();
		booksDto.setBook_id(books.getBook_id());
		booksDto.setBook_name(books.getBook_name());
		booksDto.setBook_authorizar(books.getBook_authorizar());
		booksDto.setBook_price(books.getBook_price());
		booksDto.setCustomer_id(books.getCustomer_id());

		return booksDto;
	}

	public String updateBooks(String book_id, String book_authorizer, RequestBooksDto requestBooksDto) {

		booksRepo.update(book_id,book_authorizer,requestBooksDto);

		return "success";

	}

	public String deleteBooksById(String book_id, String book_authorizer) {
		booksRepo.deleteBooksById(book_id,book_authorizer);
		return "Successfully deleted";
	}

	public List<BooksDto> getAllBooks() {
		
		List<BooksDto> listBookDto= new ArrayList<>();
	     List<Books> books= booksRepo.getAllBooks();
	     
	     for(Books b:books) {
	    	 BooksDto booksDto=new BooksDto();
	    	 booksDto.setBook_id(b.getBook_id());
	    	 booksDto.setBook_name(b.getBook_name());
	    	 booksDto.setBook_authorizar(b.getBook_authorizar());
	    	 booksDto.setBook_price(b.getBook_price());
	    	 booksDto.setCustomer_id(b.getCustomer_id());
	    	 listBookDto.add(booksDto);
	     }
		
		return listBookDto;
	}

}

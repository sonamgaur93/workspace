package com.example.SpringbootDynamoDb.dto;

import lombok.Data;

@Data
public class BooksDto {

	private String book_id;
	private String book_name;
	private String book_authorizar;
	private Integer customer_id;
	private Long book_price;

}

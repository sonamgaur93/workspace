package com.example.SpringbootDynamoDb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.SpringbootDynamoDb.dto.BooksDto;
import com.example.SpringbootDynamoDb.dto.RequestBooksDto;
import com.example.SpringbootDynamoDb.repo.BooksRepo;
import com.example.SpringbootDynamoDb.service.BooksService;

@RestController
public class BooksController {


	@Autowired
	private BooksService booksService;

	@PostMapping("/books")
	public @ResponseBody BooksDto saveBooks(@RequestBody BooksDto booksDto) {

		return booksService.saveBooks(booksDto);
	}

	@GetMapping("/books/{id}/{authorizer}")
	public @ResponseBody BooksDto getBooksById(@PathVariable ("id") String book_id , @PathVariable ("authorizer") String book_authorizer ) {

		return booksService.getBooksById(book_id,book_authorizer);
	}

	@PutMapping("/books/{id}/{authorizer}")
	public String updateBooks( @PathVariable ("id") String book_id , @PathVariable ("authorizer") String book_authorizer,@RequestBody RequestBooksDto requestBooksDto ) {

		return  booksService.updateBooks(book_id,book_authorizer,requestBooksDto);
	}
	

	@DeleteMapping("/books/{id}/{authorizer}")
	public String deleteBooksById(@PathVariable ("id") String book_id , @PathVariable ("authorizer") String book_authorizer) {
		
		return  booksService.deleteBooksById(book_id,book_authorizer);
	}
	
	@GetMapping("/AllBooks")
	public @ResponseBody List<BooksDto> getAllBooks() {
		
		return booksService.getAllBooks();
	}
}

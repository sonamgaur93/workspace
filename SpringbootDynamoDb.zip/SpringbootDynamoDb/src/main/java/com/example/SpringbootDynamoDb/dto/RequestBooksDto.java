package com.example.SpringbootDynamoDb.dto;

import lombok.Data;

@Data

public class RequestBooksDto {

	
	private Integer customer_id;
	

}

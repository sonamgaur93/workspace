package com.example.SpringbootDynamoDb.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.example.SpringbootDynamoDb.dto.RequestBooksDto;
import com.example.SpringbootDynamoDb.entity.Books;

@Repository
public class BooksRepo {


	@Autowired
	private DynamoDBMapper dynamoDBMapper;

	public  void saveBooks(Books books) {
		dynamoDBMapper.save(books);
	}

	public Books getBooksById(String book_id ,String book_authorizer) {
		return dynamoDBMapper.load(Books.class, book_id , book_authorizer);

	}

	public void update(String book_id, String book_authorizer, RequestBooksDto requestBooksDto) {

		Books books =  getBooksById(book_id ,book_authorizer);
		books.setCustomer_id(requestBooksDto.getCustomer_id() !=null ?
				requestBooksDto.getCustomer_id() : books.getCustomer_id());

		dynamoDBMapper.save(books,
				new DynamoDBSaveExpression()
				.withExpectedEntry("book_id",
						new ExpectedAttributeValue(
								new AttributeValue().withS(book_id))));

	}

	public void deleteBooksById(String book_id, String book_authorizer) {
		
		Books books =  getBooksById(book_id ,book_authorizer);
		dynamoDBMapper.delete(books);
	}

	public List<Books> getAllBooks() {
		
		
		Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
//		eav.put(":bookPrice", new AttributeValue().withN("3000"));
		eav.put(":jerry", new AttributeValue().withS("jerry"));

		DynamoDBScanExpression scanExpression = new DynamoDBScanExpression()
			.withExpressionAttributeValues(eav)
		    .withFilterExpression("book_authorizar = :jerry");
		

		List<Books> books =  dynamoDBMapper.scan(Books.class, scanExpression);
		
		return books;
	    
		
	}
}

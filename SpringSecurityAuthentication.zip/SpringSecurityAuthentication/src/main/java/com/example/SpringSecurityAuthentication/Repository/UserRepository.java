package com.example.SpringSecurityAuthentication.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringSecurityAuthentication.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	
	  User findByUsername(String username); 
}




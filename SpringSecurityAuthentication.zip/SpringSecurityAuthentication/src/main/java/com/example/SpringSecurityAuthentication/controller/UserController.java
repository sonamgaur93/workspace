package com.example.SpringSecurityAuthentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringSecurityAuthentication.Dto.UserDto;
import com.example.SpringSecurityAuthentication.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService userService;
	
	@RequestMapping(value = "/api/services/controller/user/login", method = RequestMethod.POST)
	public String saveDto(@RequestBody UserDto userDto) {
//		return userService.saveDto(userDto);
		return "success";
	}

}

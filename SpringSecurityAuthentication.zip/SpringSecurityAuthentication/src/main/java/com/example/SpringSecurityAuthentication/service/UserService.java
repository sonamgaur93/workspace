package com.example.SpringSecurityAuthentication.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.example.SpringSecurityAuthentication.Dto.UserDto;

public interface UserService extends UserDetailsService{

	
	String saveDto(UserDto userDto);

}

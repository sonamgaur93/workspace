package com.example.SpringSecurityAuthentication.ServiceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.SpringSecurityAuthentication.Dto.UserDto;
import com.example.SpringSecurityAuthentication.Repository.UserRepository;
import com.example.SpringSecurityAuthentication.model.User;
import com.example.SpringSecurityAuthentication.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UserDetailServiceImpl implements UserService,UserDetailsService{

	private static final Logger logger = LoggerFactory.getLogger(UserDetailServiceImpl.class);


	@Autowired
	UserRepository userRepository;

	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;


	@Transactional(rollbackFor = Exception.class) 
	public String saveDto(UserDto userDto) { 
	    userDto.setPassword(bCryptPasswordEncoder
	           .encode(userDto.getPassword())); 
	    return "success";
	}


	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		User user = userRepository.findByUsername(username);
		ObjectMapper mapper = new ObjectMapper();
		UserDto userDto = mapper.convertValue(user, UserDto.class);
		userDto.setPassword(bCryptPasswordEncoder.encode(userDto.getPassword()));
		return null;
	}

	


}

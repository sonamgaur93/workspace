package com.example.UnitTesting;




import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.UnitTesting.entity.User;
import com.example.UnitTesting.repository.UserRepo;
import com.example.UnitTesting.service.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceTest{

	//	@Autowired
	//	private UserService subject;

	//	@MockBean
	//	private UserRepo repository;

	@Test
	public void addUserTest() {
		User user= new User(1,"sonam",12,"bhopal");
		UserRepo repomock=mock(UserRepo.class);
		
		when(repomock.save(user)).thenReturn(user);
		
		UserService servicemock= new UserService(repomock);
		assertEquals(user, servicemock.addUser(user));
	}
}


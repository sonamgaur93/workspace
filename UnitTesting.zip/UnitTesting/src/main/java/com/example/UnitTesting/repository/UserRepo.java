package com.example.UnitTesting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.UnitTesting.entity.User;

public interface UserRepo extends JpaRepository<User, Integer> {

	List<User> findByAddress(String address);

}

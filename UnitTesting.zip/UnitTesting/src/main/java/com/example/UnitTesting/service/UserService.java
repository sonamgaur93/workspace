package com.example.UnitTesting.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.UnitTesting.entity.User;
import com.example.UnitTesting.repository.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo repository;


	public UserService(UserRepo repository) {
		super();
		this.repository = repository;
	}

	public User addUser(User user) {
		System.err.println("Getting data from DB : " + user);
		return repository.save(user);

	}

	public List<User> getUsers() {
		List<User> users = repository.findAll();

		if(users.size()>1) {
			System.err.println(users.get(0).getAddress());
		}

		return users;
	}

	public List<User> getUserbyAddress(String address) {
		return repository.findByAddress(address);
	}

	public void deleteUser(User user) {
		repository.delete(user);
	}
}

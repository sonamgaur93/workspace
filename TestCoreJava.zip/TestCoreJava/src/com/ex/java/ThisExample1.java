package com.ex.java;

class ThisExample1 {  
    
    // initialize instance and static variable   
    int x = 5;  
    static int y = 10;  
      
    // default constructor of class ThisExample1  
    ThisExample1()  
    {  
        // invoking current class constructor  
        this(5);  
        System.out.println("We are insie of the default constructor.");  
        System.out.println("The value of x = "+x);  
    }  
  
    ThisExample1(int x)  
    {  
        this.x = x; // override value of the current class instance variable  
        System.out.println("We are inside of the parameterized constructor.");  
        System.out.println("The value of y = "+y);  
    }  
    public static void main(String[] args)  
    {  
        // invoking constructor of the current class  
        new ThisExample1();  
        System.out.println("Inside Main");  
    }  
}  

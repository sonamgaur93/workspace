package com.neo.capital.finance.service.imp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.neo.capital.finance.entity.Employee;
import com.neo.capital.finance.model.EmployeeDetails;
import com.neo.capital.finance.model.EmployeeDt;
import com.neo.capital.finance.model.EmployeeResponse;
import com.neo.capital.finance.model.EmployeeSaveRequest;
import com.neo.capital.finance.model.GetAllEmployee;
import com.neo.capital.finance.model.Meta;
import com.neo.capital.finance.model.Update;
import com.neo.capital.finance.model.UpdateEmployeeRequest;
import com.neo.capital.finance.model.UpdateEmployeeResponseDto;
import com.neo.capital.finance.model.UpdateName;
import com.neo.capital.finance.model.mapper.EmployeeResponseMapper;
import com.neo.capital.finance.repository.EmployeeRepository;
import com.neo.capital.finance.service.CapitalFinanceCrmService;


@Service
public class CapitalFinanceCrmServiceImp implements CapitalFinanceCrmService {

	public void initService() {
		System.err.println("init CapitalFinanceCrmServiceImp");
	}

	public void dest() {
		System.err.println("dest CapitalFinanceCrmServiceImp");
	}

	@Autowired
	public EmployeeRepository employeeRepository;

	@Autowired
	public EmployeeResponseMapper employeeResponseMapper;

	@Override
	public EmployeeResponse getEmployeeDetails(String id) {

		Optional<Employee> employee = employeeRepository.findById(Integer.valueOf(id));
		return employee.isPresent() ? 
				employeeResponseMapper.map(Meta.builder().code("CF-001").build(), 
						employee.get()) : null;
	}

	@Override
	public EmployeeResponse saveEmployeeDetails(EmployeeSaveRequest employeeSaveRequest) {
		Employee employee = new Employee();
		employee.setId(employeeSaveRequest.getId());
		employee.setName(employeeSaveRequest.getName());
		employee.setAddress(employeeSaveRequest.getAddress());
		employee.setEmail(employeeSaveRequest.getEmail());
	     employeeRepository.save(employee);
		return employeeResponseMapper.map(Meta.builder().code("CF-001").build(), employee);
	}
	
	
	
	
	public UpdateEmployeeResponseDto updateEmployeeDetails(UpdateEmployeeRequest updateEmployeeRequest) {
		UpdateEmployeeResponseDto updateEmployeeResponseDto=new UpdateEmployeeResponseDto();
		Optional<Employee> employeeOptional = employeeRepository.findById(updateEmployeeRequest.getId());
		if(employeeOptional.isPresent()) {
			Employee employee = employeeOptional.get();
			employee.setAddress(updateEmployeeRequest.getAddress());

			updateEmployeeResponseDto.setId(updateEmployeeRequest.getId());
			updateEmployeeResponseDto.setName(employee.getName());
			updateEmployeeResponseDto.setEmail(employee.getEmail());
			updateEmployeeResponseDto.setAddress(employee.getAddress());

			employeeRepository.save(employee);


		}
		return updateEmployeeResponseDto ;
	}

	public UpdateEmployeeResponseDto deleteEmployee(int id) {
		UpdateEmployeeResponseDto updateEmployeeResponseDto=new UpdateEmployeeResponseDto();	
		employeeRepository.findById(id);
		employeeRepository.deleteById(id);
		return updateEmployeeResponseDto;
	}



	public  List<UpdateEmployeeResponseDto> getEmployees(Map<String, String> requestParam) {
		
		int pageSize = Integer.valueOf(requestParam.get("pageSize"));
		int pageNumber = Integer.valueOf(requestParam.get("pageNumber")) ;
				
		Pageable pageable = PageRequest.of(pageNumber, pageSize);
		
		Page<Employee> employee=employeeRepository.findAll(pageable);
		
		List<UpdateEmployeeResponseDto> updateEmployeeResponseDtoList =new ArrayList<UpdateEmployeeResponseDto>();
      
		for(Employee employ:employee)
        {
        	
        	UpdateEmployeeResponseDto UpdateEmployeeResponseDto = new UpdateEmployeeResponseDto();
        	UpdateEmployeeResponseDto.setId(employ.getId());
        	UpdateEmployeeResponseDto.setName(employ.getName());
        	UpdateEmployeeResponseDto.setAddress(employ.getAddress());
        	UpdateEmployeeResponseDto.setEmail(employ.getEmail());
        	
        	updateEmployeeResponseDtoList.add(UpdateEmployeeResponseDto);
        	
        }
      
		return updateEmployeeResponseDtoList;

	}
	
	
	public Update details(UpdateName name) {
		Update update =new Update();
		Optional<Employee> employ=employeeRepository.findById(name.getId());
		if(employ.isPresent()) {
			Employee employee=employ.get();
			employee.setName(name.getName());
			
			update.setId(name.getId());
			update.setName(employee.getName());
			update.setAddress(employee.getAddress());
			employeeRepository.save(employee);
		}
		return update;
	}
	
	public List<EmployeeDt> getEmployee() {
		List<Employee> employee=employeeRepository.findAll();
		 List<EmployeeDt> emdt=new  ArrayList<EmployeeDt>();
		 for(Employee empl:employee) {
			 EmployeeDt em=new EmployeeDt();
			 em.setId(empl.getId());
			 em.setName(empl.getName());
			 em.setAddress(empl.getAddress());
			 em.setEmail(empl.getEmail());
			 emdt.add(em);
		 }
		 return emdt;
	}

}

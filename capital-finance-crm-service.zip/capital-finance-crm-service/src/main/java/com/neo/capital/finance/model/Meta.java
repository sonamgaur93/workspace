package com.neo.capital.finance.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Meta {
	
 private String code;
 private String mesage;

}

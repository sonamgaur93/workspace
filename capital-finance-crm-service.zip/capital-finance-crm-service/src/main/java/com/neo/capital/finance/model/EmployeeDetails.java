package com.neo.capital.finance.model;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class EmployeeDetails {

	private Integer id;
	
	private String name;
	
	private String address;
	private String email;
}

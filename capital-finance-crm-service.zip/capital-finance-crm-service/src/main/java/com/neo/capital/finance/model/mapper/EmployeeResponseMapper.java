package com.neo.capital.finance.model.mapper;

import org.springframework.stereotype.Component;

import com.neo.capital.finance.entity.Employee;
import com.neo.capital.finance.model.EmployeeDetails;
import com.neo.capital.finance.model.EmployeeResponse;
import com.neo.capital.finance.model.Meta;

@Component
public class EmployeeResponseMapper {

	public EmployeeResponse map(Meta meta, Employee employee) {
		return EmployeeResponse.builder()
				.data(map(employee))
				.build();

	}
	
	public EmployeeDetails map(Employee employee) {
		return EmployeeDetails.builder()
				.id(employee.getId())
				.name(employee.getName())
				.address(employee.getAddress())
				.email(employee.getEmail())
				.build();

	}

}

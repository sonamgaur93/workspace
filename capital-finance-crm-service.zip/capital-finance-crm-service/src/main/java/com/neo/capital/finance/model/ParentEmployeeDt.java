package com.neo.capital.finance.model;

public class ParentEmployeeDt {

}

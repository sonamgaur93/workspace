package com.neo.capital.finance.model;

import java.util.List;

public class GetAllEmployee {


public 	List<UpdateEmployeeResponseDto> employee;

public List<UpdateEmployeeResponseDto> getEmployee() {
	return employee;
}

public void setEmployee(List<UpdateEmployeeResponseDto> employee) {
	this.employee = employee;
}

@Override
public String toString() {
	return "GetAllEmployee [employee=" + employee + "]";
}




}

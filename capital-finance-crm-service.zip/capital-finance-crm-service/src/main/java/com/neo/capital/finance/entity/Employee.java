package com.neo.capital.finance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "employee")
public class Employee  {
	
	@Id
	private Integer id;
	
	@Column
	private String name;
	
	@Column
	private String address;
	
	@Column
	private String email;

}

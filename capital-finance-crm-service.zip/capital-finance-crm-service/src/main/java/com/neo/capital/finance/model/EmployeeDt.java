package com.neo.capital.finance.model;

public class EmployeeDt {
private Integer id;
	
	private String name;
	
	@Override
	public String toString() {
		return "EmployeeDt [id=" + id + ", name=" + name + ", address=" + address + ", email=" + email + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String address;
	private String email;
}

package com.neo.capital.finance.service;

import java.util.List;
import java.util.Map;

import com.neo.capital.finance.model.EmployeeDetails;
import com.neo.capital.finance.model.EmployeeDt;
import com.neo.capital.finance.model.EmployeeResponse;
import com.neo.capital.finance.model.EmployeeSaveRequest;
import com.neo.capital.finance.model.Update;
import com.neo.capital.finance.model.UpdateEmployeeRequest;
import com.neo.capital.finance.model.UpdateEmployeeResponseDto;
import com.neo.capital.finance.model.UpdateName;

public interface CapitalFinanceCrmService {

	public EmployeeResponse getEmployeeDetails(String id);
	public EmployeeResponse saveEmployeeDetails(EmployeeSaveRequest employeeSaveRequest);
	public UpdateEmployeeResponseDto updateEmployeeDetails( UpdateEmployeeRequest updateEmployeeRequest);
	public UpdateEmployeeResponseDto deleteEmployee(int id);
	public List<UpdateEmployeeResponseDto> getEmployees(Map<String, String> requestParm);
	public Update details(UpdateName name);
	public List<EmployeeDt> getEmployee();
	
}

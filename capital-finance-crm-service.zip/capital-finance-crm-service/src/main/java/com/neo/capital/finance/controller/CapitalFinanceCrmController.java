package com.neo.capital.finance.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neo.capital.finance.model.EmployeeDt;
import com.neo.capital.finance.model.EmployeeResponse;
import com.neo.capital.finance.model.EmployeeSaveRequest;
import com.neo.capital.finance.model.GetAllEmployee;
import com.neo.capital.finance.model.Update;
import com.neo.capital.finance.model.UpdateEmployeeRequest;
import com.neo.capital.finance.model.UpdateEmployeeResponseDto;
import com.neo.capital.finance.model.UpdateName;
import com.neo.capital.finance.service.CapitalFinanceCrmService;

@Controller

public class CapitalFinanceCrmController {
	
	@Autowired
	public CapitalFinanceCrmService capitalFinanceCrmService;
	
	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		model.put("message", "welcome sonam");
		return "welcome";
	}
	
	@RequestMapping("/login")
	public String login(Map<String, Object> model) {
		model.put("message", "Login page");
		return "login";
	}
	
	
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET)
	public @ResponseBody EmployeeResponse getEmployeeByid(@PathVariable("id") String id){
		return capitalFinanceCrmService.getEmployeeDetails(id);
	}

	
	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public @ResponseBody EmployeeResponse saveEmployeeDetails(@RequestBody EmployeeSaveRequest employeeSaveRequest){
		return capitalFinanceCrmService.saveEmployeeDetails(employeeSaveRequest);
	}

	
	@RequestMapping(value = "/employee", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody UpdateEmployeeResponseDto updateEmployeeDetails(@RequestBody UpdateEmployeeRequest updateEmployeeRequest){
		return capitalFinanceCrmService.updateEmployeeDetails(updateEmployeeRequest);
	}

	@RequestMapping(value = "{id}", method = RequestMethod.DELETE)
	public @ResponseBody UpdateEmployeeResponseDto  deleteEmployee(@PathVariable("id") int id) {
		return capitalFinanceCrmService.deleteEmployee(id);
	}
	
	@RequestMapping(value = "/employeedetails", method = RequestMethod.GET)
	public ResponseEntity<GetAllEmployee > getEmployees(@RequestParam Map<String, String> requestParm){
		GetAllEmployee getAllEmployee=new GetAllEmployee();
		
		List<UpdateEmployeeResponseDto> updateEmployeeResponseDto=capitalFinanceCrmService.getEmployees(requestParm);
		getAllEmployee.setEmployee(updateEmployeeResponseDto);
		return ResponseEntity.badRequest().body(getAllEmployee);
	}
	
	
	
	@RequestMapping(value = "/details", method = RequestMethod.PUT)
	public @ResponseBody  Update details(@RequestBody UpdateName name) {
		
		return capitalFinanceCrmService.details(name);
	}
	
	
	@RequestMapping(value = "/emp", method = RequestMethod.GET)
	public @ResponseBody List<EmployeeDt> getEmployee()  {
		return capitalFinanceCrmService.getEmployee();
}
}
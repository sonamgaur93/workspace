package com.neo.capital.finance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import com.neo.capital.finance.service.CapitalFinanceCrmService;
import com.neo.capital.finance.service.imp.CapitalFinanceCrmServiceImp;

@SpringBootApplication
public class CapitalFinanceCrmServiceApplication extends SpringBootServletInitializer {
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CapitalFinanceCrmServiceApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(CapitalFinanceCrmServiceApplication.class, args);
	}
	
	@Bean(initMethod = "initService", destroyMethod = "dest")
	public CapitalFinanceCrmService capitalFinanceCrmService() {
		return new CapitalFinanceCrmServiceImp();
	}

}

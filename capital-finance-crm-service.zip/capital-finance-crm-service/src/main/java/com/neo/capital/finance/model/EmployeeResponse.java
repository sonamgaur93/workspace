package com.neo.capital.finance.model;

import lombok.Builder;
import lombok.Data;

@Data

@Builder
public class EmployeeResponse {

	private Meta meta;	

	private EmployeeDetails data;

}

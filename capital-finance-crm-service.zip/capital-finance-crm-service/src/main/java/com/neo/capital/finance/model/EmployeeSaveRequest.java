package com.neo.capital.finance.model;

import lombok.Data;

@Data
public class EmployeeSaveRequest {

	private Integer id;

	private String name;
	
	private String address;
	

	private String email;
}

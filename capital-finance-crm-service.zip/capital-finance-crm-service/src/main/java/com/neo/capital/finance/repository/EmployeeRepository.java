package com.neo.capital.finance.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.neo.capital.finance.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{


}

package com.neo.capitalfinancecrmservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapitalFinanceCrmServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

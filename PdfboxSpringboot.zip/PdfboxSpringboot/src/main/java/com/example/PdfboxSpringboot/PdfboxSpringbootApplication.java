package com.example.PdfboxSpringboot;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;

import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.encryption.StandardProtectionPolicy;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfboxSpringbootApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(PdfboxSpringbootApplication.class, args);

		//		for crating a pdf file
		//		PDDocument document = new PDDocument();
		//		PDPage firstPage= new PDPage();
		//		document.addPage(firstPage);
		//		document.save("C:\\pdf\\mypdf.pdf");
		//		System.err.println("pdf created");
		//		document.close();


		////		for loading a pdf file
		//		File file = new File("C:\\pdf\\Oldpdf.pdf");
		//		PDDocument document= PDDocument.load(file);
		//		document.save("C:\\pdf\\mypdf.pdf");
		//		System.err.println("Load new file");
		//		document.close();



		//		for spliting the  pdf one by one
		
		//		File file = new File("C:\\pdf\\Oldpdf.pdf");
		//		PDDocument document= PDDocument.load(file);

		//		Splitter splitter = new Splitter();
		//		List<PDDocument> splitList = splitter.split(document);
		//		 
		//		int num=1;
		//		for(PDDocument mydoc: splitList) {
		//			mydoc.save("C:\\pdf\\splitter\\split_0"+num+".pdf");
		//			num++;
		//			mydoc.close();
		//		}
		//		System.err.println("splitting done");




		//for spliting the  pdf range 1 to 10 etc
//		File oldfile = new File("C:\\pdf\\Oldpdf.pdf");
//		PDDocument document= PDDocument.load(oldfile);
//
//		Splitter splitter = new Splitter();
//		splitter.setStartPage(1);
//		splitter.setEndPage(2);
//
//		List<PDDocument> splitList = splitter.split(document);
//		PDDocument newDocument= new PDDocument();
//
//		for(PDDocument mydoc: splitList) {
//			newDocument.addPage(mydoc.getPage(0));
//		}
//
//		newDocument.save("C:\\\\\\\\pdf\\\\\\\\splitter\\\\\\\\RangeSplitter.pdf");
//		newDocument.close();
//		System.err.println("splitting done according to range");
//		
		
	
		
//		Delete pages range wise
		
//		File oldfile = new File("C:\\pdf\\Oldpdf.pdf");
//		PDDocument document= PDDocument.load(oldfile);
//		
//		int pageStartRange =2;
//		int pageEndRange=4;
//		
//		for(int i=pageEndRange;i>=pageStartRange;i--) {
//			document.removePage(i-1);
//		}
//		
//		document.save("c:\\pdf\\delete.pdf");
//		document.close();
//		System.err.println("delete according to range");
		
		
		
		
////		Mergering the  pdf files
//		File oldfile1 = new File("C:\\pdf\\splitter\\split_01.pdf");
//		File oldfile2 = new File("C:\\pdf\\splitter\\split_02.pdf");
//		
////		File newFile = new File("C:\\pdf\\splitter\\mergeFile.pdf");
//		
//		PDFMergerUtility mergerUtility = new PDFMergerUtility();
//		mergerUtility.setDestinationFileName("C:\\pdf\\splitter\\mergeFile.pdf");
//		
//		mergerUtility.addSource(oldfile1);
//		mergerUtility.addSource(oldfile2);
//		
//		mergerUtility.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());
//		
//		System.err.println("merge documents");
		
		
		
		
		
//		Set Document properties and protecton security
		
//		PDDocument document= new PDDocument();
//		PDPage page = new PDPage();
//		
//		document.addPage(page);
//		
//		document.save("C:\\pdf\\documentSet.pdf");
//		PDDocumentInformation documentInformation =document.getDocumentInformation();
//		documentInformation.setTitle("PdfCreation");
//		documentInformation.setAuthor("sonam");
//		documentInformation.setCreator("Apache PdfBox");
//		documentInformation.setCreationDate(Calendar.getInstance());
//		documentInformation.setKeywords("Apache,java");
//		
//		
//		final int keyLength=128;
//		AccessPermission accessPermission= new AccessPermission();
//		StandardProtectionPolicy policy =new StandardProtectionPolicy("12345", "hello", accessPermission);
//		policy.setEncryptionKeyLength(keyLength);
//		policy.setPermissions(accessPermission);
//		
//		document.protect(policy);
//		
//		
//		document.save("C:\\\\pdf\\\\documentSet.pdf");
//		document.close();
//		System.err.println("properties set");
//		
//		
		
		
		
//		adding text  in the pdf
//		
//		PDDocument document= new PDDocument();
//		PDPage page = new PDPage();
//		document.addPage(page);
//
//		PDPageContentStream contentStream = new	PDPageContentStream(document, page);
//		contentStream.beginText();
//		contentStream.setFont(PDType1Font.TIMES_ROMAN, 20);
//		contentStream.setLeading(16.0f);
//
//		contentStream.newLineAtOffset(25, page.getTrimBox().getHeight()-25);
//		String text1 = "This the first line";
//		String text2 = "This is the second line";
//		String text3 = "This is the third line";
//
//		contentStream.showText(text1);
//		contentStream.newLine();
//		contentStream.showText(text2);
//		contentStream.newLine();
//		contentStream.showText(text3);
//
//		contentStream.endText();
//		contentStream.close();
//
//		document.save("C:\\\\pdf\\\\documentSet.pdf");
//		document.close();
//		System.err.println("new created document");

		
		
		
//		creating pdf with image
		
//		PDDocument document= new PDDocument();
//		PDPage page = new PDPage();
//    	document.addPage(page);
//    	
//    	PDImageXObject imageXObject = PDImageXObject.createFromFile("C:\\pdf\\flower.jpg", document);
//    	PDPageContentStream contentStream = new PDPageContentStream(document, page);
//    	contentStream.drawImage(imageXObject,10,10,320,212);
//    	contentStream.close();
//		document.save("C:\\\\pdf\\\\documentSet.pdf");
//		document.close();
//		
//		System.err.println("image added");
		
	
		
		
//		adding the number list with the item
		
//
//		PDDocument document= new PDDocument();
//		PDPage page = new PDPage();
//		document.addPage(page);
//
//		PDPageContentStream contentStream = new	PDPageContentStream(document, page);
//		contentStream.beginText();
//		contentStream.setLeading(16.0f);
//		contentStream.newLineAtOffset(25, page.getTrimBox().getHeight()-25);
//
//		String[] listItems = new String[] {
//				"This is the first line",
//				"This is the second line",
//				"This is the third line",
//				"This is the fourth line",
//				"This is the fifth line"
//		};
//
//		int startListItems =1;
//
//		for(String listItem : listItems) {
//			contentStream.setFont(PDType1Font.TIMES_ROMAN,20);
//			contentStream.showText(String.valueOf(startListItems)+". ");
//			contentStream.showText(listItem);
//			contentStream.newLine();
//			startListItems++;
//		}
//
//		contentStream.endText();
//		contentStream.close();
//
//
//		document.save("C:\\\\pdf\\\\documentSet.pdf");
//		document.close();
//		System.err.println("number added in the document");
		
		
		
//		table creation
		
//		PDDocument document= new PDDocument();
//	    PDPage page = new PDPage();
//		document.addPage(page);
//		
//		int pageHeight = (int) page.getTrimBox().getHeight();
//		int pageWidth = (int) page.getTrimBox().getWidth();
//		PDPageContentStream contentStream = new	PDPageContentStream(document, page);
//		contentStream.setStrokingColor(Color.BLUE);
//		contentStream.setLineWidth(1);
//		
//		int initX = 50;
//		int initY = pageHeight-50;
//		int cellHeight = 30;
//		int cellWidth = 100;
//		
//		int colCount =5;
//		int rowCount =10;
//		
//		
//		for(int i=1 ; i<= rowCount; i++) {
//			for (int j=1;j<=colCount;j++) {
//				contentStream.addRect(initX, initY, cellWidth, -cellHeight);
//				contentStream.beginText();
//				contentStream.newLineAtOffset(initX+10, initY-cellHeight+10);
//				contentStream.setFont(PDType1Font.TIMES_ROMAN, 20);
//				contentStream.showText("sonam");
//				contentStream.endText();
//				initX+=cellWidth;
//			}
//			initX = 50;
//			initY-=cellHeight;
//		}
//		contentStream.stroke();
//		contentStream.close();
//		
//		
//		document.save("C:\\\\pdf\\\\documentSet.pdf");
//        document.close();
//        System.err.println("table created");
//		
		
		
		
//	adding some extra 	
//
		PDDocument document= new PDDocument();
		PDRectangle myPageSize = new PDRectangle(600,900); 

		PDPage page = new PDPage(myPageSize);
		document.addPage(page);

		int pageHeight = (int) page.getTrimBox().getHeight();
		int pageWidth = (int) page.getTrimBox().getWidth();

		PDPageContentStream contentStream = new	PDPageContentStream(document, page);
		contentStream.setNonStrokingColor(Color.RED);
		contentStream.addRect(0,800, pageWidth, pageWidth);
		contentStream.fill();


		contentStream.beginText();
		contentStream.setFont(PDType1Font.TIMES_ROMAN,40);
		contentStream.newLineAtOffset(150,830);

		String text="hello ,how are you";
		contentStream.setNonStrokingColor(Color.WHITE);
		contentStream.showText(text);
		contentStream.endText();


		PDImageXObject imageXObject = PDImageXObject.createFromFile("C:\\pdf\\flower.jpg", document);
		contentStream.drawImage(imageXObject,10,500,200,300);


		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, 20);
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.newLineAtOffset(300, 700);
		contentStream.setLeading(30);
		String [] header = {"Name","Age","DOB","Skill"};
		for(String detail:header) {
			contentStream.showText(detail);
			contentStream.newLine();
		}
		contentStream.endText();
		
		
		
		contentStream.beginText();
		contentStream.setFont(PDType1Font.HELVETICA_BOLD, 20);
		contentStream.setNonStrokingColor(Color.BLACK);
		contentStream.newLineAtOffset(360, 700);
		contentStream.setLeading(30);
		String [] info = {"Sonam Gour","27","26-03-1993","Dancing"};
		
		for(String userdetail:info) {
			contentStream.showText(":  "+userdetail);
			contentStream.newLine();
		}
		contentStream.endText();

		contentStream.close();
		
		
		
		document.save("C:\\\\pdf\\\\documentSet.pdf");
		
		PDFTextStripper pdfTextStripper = new PDFTextStripper();
		String doc = pdfTextStripper.getText(document);
		
		System.err.println(doc);
		
		

		document.close();
		System.err.println("New features added");
		 
		
	}
}



package com.arjuncodes.springemaildemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;

@SpringBootApplication
public class SpringEmailDemoApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(SpringEmailDemoApplication.class, args);
		
	}
	
	@Bean
	public SimpleMailMessage simpleMailMessage() {
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setFrom("pawargourav.rajput@gmail.com");
		mailMessage.setSubject("MailCheck");
		mailMessage.setText("Dear %s,\nMail Content : %s");
		return mailMessage;
	};
	
}

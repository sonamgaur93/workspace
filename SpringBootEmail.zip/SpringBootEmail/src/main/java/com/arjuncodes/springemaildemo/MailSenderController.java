package com.arjuncodes.springemaildemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MailSenderController {
	
	@Autowired
	EmailSenderService mailSenderService;

	@RequestMapping(value = "/sendmail", method = RequestMethod.POST)
	public String sendSimpleEmail(@RequestParam("toEmail")String toEmail, @RequestParam("subject") String subject, @RequestBody String body) {
		mailSenderService.sendSimpleEmail(toEmail, subject, body);
		return "ok";
	}
	
	@RequestMapping(value = "/sendAttachment", method = RequestMethod.POST)
	public String sendAttachment(@RequestParam("toEmail")String toEmail, @RequestParam("dear")String dear, @RequestBody String body) {
		mailSenderService.sendMail(toEmail, dear, body);
		return "ok";
	}

}

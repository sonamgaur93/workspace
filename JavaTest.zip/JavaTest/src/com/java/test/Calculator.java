package com.java.test;

public class Calculator {

	
	int add(Integer ...integers ) {
		int sum =0;
		for(Integer in : integers) {
			sum +=in;
		}
		return sum;
	}
}

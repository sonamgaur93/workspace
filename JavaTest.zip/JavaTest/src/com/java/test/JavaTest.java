package com.java.test; 

import java.util.Base64;

public class JavaTest {

	public static void main(String[] args) {
		
		Calculator calculator = new Calculator();
		
		int sum = calculator.add(1,2,3);
		
		System.err.println("sum :: " +sum);
		
//		String s = "sonam";
//		String base64Encode = Base64.getEncoder().encodeToString(s.getBytes());
//		
//		System.out.println("base64Encode :: " + base64Encode);
//		
//		System.out.println("base64Decode :: " + new String(Base64.getDecoder().decode(base64Encode)));
//				
//				

	}

}

package com.example.test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

class Employee{
	private int id;
	private String name;
	private Long salary;


	public Employee(int id, String name, Long salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Long getSalary() {
		return salary;
	}


	public void setSalary(Long salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + "]\n";
	}
}




public class TestFilter {

	public static void main(String[] args) {

		List<Employee>  listEmployee = new ArrayList<>();

		Employee e1=new Employee(1,"sonam",10000L);
		Employee e2=new Employee(2,"gourav",20000L);
		Employee e3=new Employee(3,"ram",30000L);
		Employee e4=new Employee(4,"shyam",40000L);
		Employee e5=new Employee(5,"kuhu",50000L);

		listEmployee.add(e1);
		listEmployee.add(e2);
		listEmployee.add(e3);
		listEmployee.add(e4);
		listEmployee.add(e5);


		List<Employee> empList= new ArrayList<>();
		//		Employee emp1= new Employee(6,"mohan",200L);
		//		Employee emp2= new Employee(7,"sohan",300L);
		//		Employee emp3= new Employee(8,"rohan",400L);
		//		Employee emp4= new Employee(9,"tohan",500L);
		//		Employee emp5= new Employee(10,"gohan",600L);
		//		
		//		empList.add(emp1);
		////		empList.add(emp2);
		//		empList.add(emp3);
		//		empList.add(emp4);
		//		empList.add(emp5);


		//		empList.addAll(listEmployee);
		//		System.err.println(empList.size());



		//		List <String>  listString= new ArrayList<>();
		//		String s1="sonam";
		//		String s2="ram";



		for(Employee e :listEmployee) {
			if(e.getSalary()>=30000) {
				empList.add(e);
			}
		}
		System.err.println(empList);



	}
}

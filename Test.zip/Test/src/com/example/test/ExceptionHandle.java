package com.example.test;

class ResourceNotFoundException extends Exception{
	ResourceNotFoundException(){
		super();
	}
	ResourceNotFoundException(String errorMessage){
		super(errorMessage);
	}
}

public class ExceptionHandle {
	public static void main(String[] args) {
		try {
			throw new ResourceNotFoundException("resource");
		}catch(ResourceNotFoundException  r) {
			System.err.println(r);
		}
	}
}

package com.example.test;

public class OverloadMain {
	
	
	public static void main(String[] args) {
		OverloadMain.main();
		System.err.println("hello");
		
	}
	
	public static void main() {
       System.err.println("waah");
		
	}
	
}

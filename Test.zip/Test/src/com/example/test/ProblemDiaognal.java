package com.example.test;

import java.util.Scanner;

public class ProblemDiaognal {
	public static void main(String[] args) {
		int array[] [] = new int [3][3];

		Scanner kb = new Scanner(System.in);
		for(int r=0;r<array.length ;r++) {

			for(int c=0;c<array.length;c++) {

				array[r][c]=kb.nextInt();
			}
		}
		ProblemDiaognal.calculation(array);
	}


	private static void calculation(int[][] array) {

		int a = ProblemDiaognal.diagonalSum(array);
		int b =	ProblemDiaognal.diagonalSumLast(array); 

		if(a>b) {
			int result =a-b;
			System.err.println(result);
		}else {
			int result =b-a;
			System.err.println(result);
		}
	}

	private static int diagonalSum(int[][] array) {
		int diagonal1 =0;

		for (int r=0; r<array.length; r++) {

			diagonal1+=array[r][r];
		}
		System.err.println(diagonal1);
		return diagonal1;
	}

	public static int diagonalSumLast(int[][] array) {
		int diagonal2 =0;
		int r=array.length-1;
		for (int c= 0; c <=r; c++) {
			diagonal2+=array[r-c][c];
		}
		System.err.println(diagonal2);
		return diagonal2;
	}

}

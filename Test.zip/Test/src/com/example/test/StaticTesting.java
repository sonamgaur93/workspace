package com.example.test;

public class StaticTesting {

	 static String s;
	
	
	public static void main(String[] args) {
		StaticTesting.s="ram";
		StaticTesting.s="shyam";
		System.err.println(s);
		StaticTesting s1= new StaticTesting();
		s1.s="sonam";
		StaticTesting s2=new StaticTesting();
		s2.s="gourav";
		System.err.println(s1.s);
		System.err.println(s2.s);
}
}

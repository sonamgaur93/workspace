package com.example.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestField {

	public static void main(String [] args) {

		List<String> list= new ArrayList<>();
		list.add("sonam");
		list.add("sonam");
		list.add("ram");
		list.add("pawan");

		System.err.println(list);

		Map<String,Integer> map= new HashMap<>();
		
//		map.put("rrrrr",1);
//		
//		System.err.println(map.get("rrrrr"));

		for(String s:list) {
			if(map.containsKey(s)) {
				map.put(s,map.get(s)+1);
			}else
				map.put(s, 1);

		}System.err.println(map);


	}
}

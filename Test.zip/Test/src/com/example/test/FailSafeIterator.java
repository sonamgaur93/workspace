package com.example.test;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class FailSafeIterator {

	public static void main(String[] args) {
		
		ConcurrentHashMap<Integer,String> map = new ConcurrentHashMap<>();
		
		map.put(1, "sonam");
		map.put(2,"gourav");
		map.put(3,"ram");
		
		for(Entry mapEntry : map.entrySet()) {
			System.err.println(mapEntry.getKey());
			System.err.println(mapEntry.getValue());
			map.put(4, "shyam");
			
		}
	}

}

package com.example.test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamTest {

	public static void main(String[] args) {

		List<String> list = new ArrayList<>();
		list.add("sonam");
		list.add("gourav");
		list.add("ram");
		list.add("shyam");


		List<Integer> list1 = new ArrayList<>();
		list1.add(2);
		list1.add(4);
		list1.add(3);
		list1.add(6);
		list1.add(1);
		list1.add(8);


		list.stream().filter(i->i=="sonam").collect(Collectors.toList()).forEach(System.out::println);
		list.stream().map(i->i+" gour").collect(Collectors.toList()).forEach(System.out::println);

		long in =list1.stream().filter(i->i%2==0).count();
		System.err.println(in);
		
		Integer minList = list1.stream().min((i1,i2)->i1.compareTo(i2)).get();
		System.err.println(minList);
		
		Integer maxList = list1.stream().max((i1,i2)->i1.compareTo(i2)).get();
		System.err.println(maxList);
		
		list1.stream().sorted((i1,i2)->(i1<i2)?1:(i1>i2)?-1:0).collect(Collectors.toList()).forEach(System.out::println);
		list1.stream().sorted().collect(Collectors.toList()).forEach(System.out::println);
		
		
		Integer[] array = list1.stream().toArray(Integer[]::new);
		
		for(Integer itr : array) {
			System.err.println(itr);
		}
		
		
		Stream.of(array).forEach(System.out::println);
		
		list1.parallelStream().forEachOrdered(System.out::println);
		
	}


}

package com.example.test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Teacher{
	int id;
	String name;
	String address;
	public Teacher(int id, String name, String address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	
	
}

public class ComparableTesting {

	public static void main(String[] args) {
		List<Teacher> list= new ArrayList<>();
		
		list.add(new Teacher(1,"sonam","malhargarh"));
		list.add(new Teacher(2,"ram","manakpur"));
		list.add(new Teacher(3,"gourav","bhopal"));
      list.stream().filter(i1->i1.name=="sonam").collect(Collectors.toList()).forEach(System.out::println);
		
	}

}

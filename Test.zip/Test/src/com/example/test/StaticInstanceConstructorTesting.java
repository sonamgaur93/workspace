package com.example.test;

public class StaticInstanceConstructorTesting {

	{
		System.out.println("Instance block is executed");
	}
	
	
	StaticInstanceConstructorTesting() {
		System.err.println("constructor block executed");
	}

	
	{
		System.out.println(" second Instance block is executed");
	}
	
	
	static {
		System.err.println("static block executed");
	}

	
	public static void main(String[] args) {

		StaticInstanceConstructorTesting s= new StaticInstanceConstructorTesting();

	}

}

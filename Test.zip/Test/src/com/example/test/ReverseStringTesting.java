package com.example.test;

public class ReverseStringTesting {

	public static void main(String[] args) {

		String s="sonam is name my";
		String s1[]=s.split(" ");
		
		for(int s2=s1.length-1; s2>=0; s2--) {
			System.err.print(s1[s2]+ " ");
			
		}
	


	}
}


package com.example.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListTest {

	
		  public static<T> T[] subArray(T[] array, int beg, int end) {
		        return Arrays.copyOfRange(array, beg, end);
		    }
		    public static void main(String[] args)
		    {
		        String[] arr = { "A", "B", "C", "D", "E", "F", "G", "H" };
		        int beg = 1, end = 4;
		 
		        String[] subarray = subArray(arr, beg, end);
		        System.out.println(Arrays.toString(subarray));
		    }
}

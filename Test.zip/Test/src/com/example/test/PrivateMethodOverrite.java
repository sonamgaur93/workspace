package com.example.test;

 class Test{
	 int id;
	 String name;
	 
	public Test(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public void show() {
		 System.err.println("id is:" +id+ "name is:"+name);
	 }
	
}

 
 class Test1{
	 int eid;
	 String ename;
	public Test1(int eid, String ename) {
		super();
		this.eid = eid;
		this.ename = ename;
	}
	 
	
	public void show() {
		 System.err.println("id is:" +eid+ "name is:"+ename);
	 } 
	 
 }

public class PrivateMethodOverrite {

	public static void main(String[] args) {
		Test1 t1 = new Test1(1, "sonam");
		
		t1.show();
		

	}

}

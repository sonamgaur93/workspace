package com.example.test;


class SingletonDesign{
	
	private static SingletonDesign s= new  SingletonDesign();
	
	private SingletonDesign() {}
	
	public static SingletonDesign get() {
		return s;
	}
}

public class SingletonTesting {

	public static void main(String[] args) {
		SingletonDesign s1= SingletonDesign.get();
		SingletonDesign s2= SingletonDesign.get();
		System.err.println(s1);
		System.out.println(s2);
	}

}

package com.example.test;

import java.util.Objects;

class Testing{
	
	int id;
	String name;
	String address;
	
	public Testing(int id, String name, String address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Testing [id=" + id + ", name=" + name + ", address=" + address + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, id, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Testing other = (Testing) obj;
		return Objects.equals(address, other.address) && id == other.id && Objects.equals(name, other.name);
	}
	
	
}

public class EqualsTesting {

	public static void main(String[] args) {
		
		Testing t1= new Testing(1,"sonam","bhopal");
		Testing t2 =new Testing(2,"ram","malhargarh");
		Testing t3= new Testing(1,"gourav","bhopal");
		
		
		String s1="sonam";
		String s2="sonam";
		System.err.println(s1.equals(s2));

		if(t1.equals(t3)) {
			System.out.println("name same");
		}
		
		System.err.println(t1.hashCode());
		System.err.println(t3.hashCode());
	}

}

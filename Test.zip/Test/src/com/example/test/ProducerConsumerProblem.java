package com.example.test;

import java.util.ArrayList;
import java.util.List;

public class ProducerConsumerProblem  {

	public static void main(String[] args) throws InterruptedException {

		ProducerConsumer pc = new ProducerConsumer();
		Thread t1 = new Thread() {
			public void run() {
				try {
					pc.producer();
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		};

		Thread t2 = new Thread() {
			public void run() {

				try {
					pc.consumer();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};

		t1.start();
		t2.start();

		t1.join();
		t2.join();
	}	  

}

class ProducerConsumer {

	List<String> list = new ArrayList<>();

	int size =4;
	public void producer() throws InterruptedException {
		while(true) {
			synchronized (this) { 
				while(list.size()==size)
					wait();

				list.add("sonam");
				list.add("gour");
				list.add("gourav");
				list.add("rajpoot");

				System.err.println("Producer produced:"+list);
				notify();
				Thread.sleep(1000);
			}	 
		}
	}
	public void consumer() throws InterruptedException {

		while(true) {
			synchronized (this) {

				while(list.size()==0)
				wait();

				for(int i=0;i<list.size();i++) {

					String s = list.remove(i);	
					System.out.println("consumer consumed:" +s);
				}
				notify();
				Thread.sleep(1000);
			}
		}
	}

}

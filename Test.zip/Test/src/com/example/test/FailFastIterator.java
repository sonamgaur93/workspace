package com.example.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class FailFastIterator {

	public static void main(String[] args) {

		Map<Integer,String> map =new HashMap<>();
		map.put(1,"sonam");
		map.put(2, "gourav");
		map.put(3, "ram");
		
		for(Entry mapEntry:map.entrySet()) {
		System.err.println(mapEntry.getKey());
		System.err.println(mapEntry.getValue());
		map.put(4,"shyam");
	}

	}
}

package com.example.test;

public class RepatitiveNo {

	public static void main(String[] args) {
		
		int[] array = {3,3,4,5,6,4,5};

		for (int i = 0; i < array.length; i++) {
		  
			boolean dupNo = false;
		    for (int j = 0; j < array.length; j++) {
		        
		    	if ( array[i] == array[j] && i != j ) {
		            dupNo = true;
		            break;
		        }
		    }
		    if (!dupNo) {
		        System.out.println(array[i]);
		    }
		}
	}

}

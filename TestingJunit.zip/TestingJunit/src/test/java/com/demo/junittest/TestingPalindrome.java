package com.demo.junittest;



import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class TestingPalindrome {

	
	@ParameterizedTest
	@ValueSource(strings ={"liril","sonam","mam"})
	public void palindromeTest(String str) {
		Palindrome test= new Palindrome();
		boolean actualResult = test.palin(str);
		assertTrue(actualResult);
	}
}

package com.demo.junittest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestingCalculater {

	private  static Calculator calc = null;

	@BeforeClass
	public static void beforeAll() {
		calc = new Calculator();
	}

	@AfterClass
	public static void afterAll() {
		calc=null;
	}

	@Test
	public void addTest() {

		int expectedResult = calc.add(12,10);
		int actualResult =22;
		assertEquals(expectedResult, actualResult);
	}

	@Test
	public void multiplyTest() {

		int expectedResult = calc.multiply(12,10);
		int actualResult =120;
		assertEquals(expectedResult, actualResult);
	}
	
	
}

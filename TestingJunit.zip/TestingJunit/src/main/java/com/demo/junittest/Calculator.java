package com.demo.junittest;

public class Calculator {

	public int add(int a,int b) {
		int sum = a+b;
		System.err.println(sum);
		return sum;
	}

	public int multiply(int a,int b) {
		int multi = a*b;
		System.err.println(multi);
		return multi;
	}
}

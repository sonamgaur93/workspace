package com.demo.junittest;

public class Palindrome {

	public boolean palin(String str) {

		String rev="";
		for(int i= str.length()-1;i>=0;i--) {
			rev=rev+str.charAt(i);
		}
		if(rev.equals(str)) {
			return true;
		}else
			return false;
	}
}

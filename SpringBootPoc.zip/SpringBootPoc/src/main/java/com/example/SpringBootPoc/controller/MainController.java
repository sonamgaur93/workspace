package com.example.SpringBootPoc.controller;

public class MainController {

}

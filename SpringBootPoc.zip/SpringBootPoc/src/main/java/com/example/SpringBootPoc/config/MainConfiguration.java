package com.example.SpringBootPoc.config;

public class MainConfiguration {

}
